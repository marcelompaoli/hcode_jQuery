# curso-jquery-books-admin
Este repositório contém os códigos do projeto de Gerenciamento de Livros, desenvolvido no curso jQuery - Curso Completo, da Hcode
