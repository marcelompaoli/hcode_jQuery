$('#disable_effects').on('click', function(){
                    
    jQuery.fx.off = !jQuery.fx.off;

});