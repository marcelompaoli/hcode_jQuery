/*
$('h1').on('dblclick', function(){

    $(this).text('Hcode Treinamentos - jQuery');

});
*/

// Acionando um evento manualmente
// $('h1').trigger('dblclick')

$('#form_login').on('submit', function(event){

    event.preventDefault();

    console.log('Aqui estão os valores do formulário', $(this).serializeArray());

});

$('#form_login [name=bio]').on('blur', function(e){

    $(e.target.form).trigger('submit');

});