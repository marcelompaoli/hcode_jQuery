// Retornando ou definindo um atributo
// $('img').attr('src', 'assets/images/jquery.jpg')

// Removendo um atributo
// $('h1').removeAttr('title')