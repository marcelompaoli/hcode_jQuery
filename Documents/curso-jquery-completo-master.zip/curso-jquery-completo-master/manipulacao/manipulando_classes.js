// Adicionando uma classe
// $('header .menu ul li:last a').addClass('stylized_menu')

// Removendo uma classe
// $('header .menu ul li:last a').removeClass('stylized_menu')

// Alternando uma classe
// $(this).toggleClass('stylized_menu');

// Verificando se um elemento possui uma classe
// $('header .menu ul li:last a').hasClass('banana');

$('header .menu ul li a').click(function(event){

    event.preventDefault();

    $(this).toggleClass('stylized_menu');

});

$('p').each(function(){

    if ($(this).hasClass('paragrafo')) {
        $(this).append(`<span style="color: red;"> - Eu tenho a classe</span>`)
    }

});