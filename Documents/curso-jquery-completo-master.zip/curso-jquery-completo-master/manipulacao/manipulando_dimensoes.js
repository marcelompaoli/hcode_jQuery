// Retorna ou define a largura de um elemento
// $('.paragrafo').width(500);

// Retorna ou define a largura de um elemento, levando em conta o padding
// $('.paragrafo').innerWidth();

// Retorna ou define a altura de um elemento
// $('.paragrafo').height(100);

// Retorna ou define a altura de um elemento, levando em conta o padding
// $('.paragrafo').innerHeight();