// Retornando ou definindo a posição de um elemento
// $('form .field:eq(1)').offset({
//     top: 5,
//     left: 100
// })

// Retornando a posição de um elemento se baseando no elemento pai
// $('form .field:eq(1)').position();

// Retornando ou definindo a posição da barra de rolagem vertical
// $(document).scrollTop(400);

// Retornando ou definindo a posição da barra de rolagem horizontal
// $(document).scrollLeft(600);