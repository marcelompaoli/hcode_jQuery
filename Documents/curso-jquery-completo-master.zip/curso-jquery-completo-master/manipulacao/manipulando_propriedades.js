// Retorna ou define uma propriedade
// $('form [type=checkbox]').prop('checked', true)

// Removendo uma propriedade
// $('h1').removeProp('nome')