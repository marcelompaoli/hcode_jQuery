// Retornando ou definindo o valor de um campo
// $('form [type=text]:first').val('John Resig')
// $('form [type=date]').val('1977-05-25')