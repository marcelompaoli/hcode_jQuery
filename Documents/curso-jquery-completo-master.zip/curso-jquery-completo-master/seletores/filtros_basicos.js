// Selecionando o último elemento                
// $('.cars_list li:last').click(function(){
//     alert('ok');
// });

// Selecionando o primeiro elemento
// $('.cars_list li:first').click(function(){
//     console.log('Cliquei no primeiro item')
// })

// Selecionando elementos de maneira alternada, começando pelos ímpares
// $('.cars_list li:even').css('background-color', '#ccc')

// Selecionando elementos de maneira alternada, começando pelos pares
// $('.cars_list li:odd').css('background-color', '#ccc')

// Selecionando um elemento em uma posição específica (baseado em um array)
// $('.cars_list li:eq(0)').css('font-size', '40px')

// Selecionando todos os elementos abaixo de outro
// $('.cars_list li:gt(2)').css('opacity', '0.3')

// Selecionando todos os elementos acima de outro
// $('.cars_list li:lt(2)').css('opacity', '0.3')