// Selecionando um elemento pelo seu conteúdo
// $('.menu li a:contains(About)').css('outline', 'solid red 2px')

// Selecionando um elemento que não possui conteúdo
// $('.cars_list li:empty').text('Vazio').css({
//     'background': 'red',
//     'color': 'white'
// });

// Selecionando os elementos que possuem conteúdo
// $('.cars_list li:parent').append('<span style="color: green;"> - Tem valor</span>')

// Selecionando os elementos que possuem outros elementos
// $('.cars_list li:has(span)').animate({
//     fontSize: '30px',
//     opacity: 0.7
// }, 2000)