// Selecionando o último elemento, mesmo que seja mais de um caso
// $('.cars_list li:last-child').css('text-decoration', 'underline')

// Selecionando o primeiro elemento, mesmo que seja mais de um caso
// $('.cars_list li:first-child').css('font-size', '25px')

// Selecionando os elementos de maneira alternada (par)
// $('.cars_list li:nth-child(even)').css('background-color', '#ccc')

// Selecionando os elementos de maneira alternada (ímpar)
// $('.cars_list li:nth-child(odd)').css('background-color', '#ccc')

// Selecionando um elemento em uma posição específica, mesmo que seja mais de um caso
// $('.cars_list li:nth-child(1)').css('font-size', '40px')

// Selecionando um elemento em uma posição específica, começando a contar do último elemento                
// $('.cars_list li:nth-last-child(3)').css('font-weight', 'bold')