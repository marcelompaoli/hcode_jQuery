// Selecionando os elementos que estão "invisíveis"
// $('.cars_list li:hidden').show()

// Selecionando os elementos visíveis
// $('.cars_list li:visible').hide();