// Verificando se possui um atributo
// $('.header-border li [href]').text('Link')

// Verificando se possui mais de um atributo
// $('.header-border li [href][title]').text('Link')

// Verificando um valor para o atributo
// $('.header-border li [href="about.html"]').text()

// Verificando os atributos que começam com uma letra específica
// $('.header-border li [href^="i"]').text()

// Verificando os atributos que termiam com uma expressão específica
// $('.header-border li [href$=".html"]').text()

// Verificando os atributos que possuem a expressão informada
// $('.header-border li [href*="in"]').text()