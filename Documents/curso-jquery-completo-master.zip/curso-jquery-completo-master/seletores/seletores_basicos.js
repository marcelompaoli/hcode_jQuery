// Nome de tag -> $('h1').css('color', 'red')
// ID -> $('#logo').html('Negócios')

// Selecionando pela classe
// $('.paragrafo').animate({
//     fontSize: '50px',
//     opacity: 0.7
// }, 5000)

// Seletor composto
// $('header nav.menu').css('border', 'solid 1px orange')

// Múltiplos seletores
// $('form, section').css('background-color', '#ccc')