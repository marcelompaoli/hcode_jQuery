// Elementos descendentes
// $('main h1').css('color', 'red')

// Elemento descendente direto
// $('main>.title').css('border', 'solid 2px blue')

// Elemento irmão mais próximo -> +
// Todos os elementos irmãos -> ~
$('.paragrafo+p').css({
    'background-color': 'red',
    'color': 'white'
})